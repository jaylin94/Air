#ifndef ITEMTYPE_HPP
#define ITEMTYPE_HPP

//enum values for item types
enum itemType
{
    //first aid
    heal = 1,
    //plug
    plugItem,
    //key
    keyItem,
    //junk
    junkItem
};

#endif