To run the program, run these commands in the same directory as the zip file:
hint: to make it easier, navigate to the directory in a terminal, then run `cat README.txt` and copy the commands from the terminal.

1)
unzip FinalProject_Lin_Jay.zip

2)
make

3)
./air
