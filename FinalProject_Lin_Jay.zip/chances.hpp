#ifndef CHANCES_HPP
#define CHANCES_HPP

//enum type for chances of success or failure
enum chances
{
    success = 1,
    failure
};

#endif